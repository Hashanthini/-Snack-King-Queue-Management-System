package com.example.w1985671_20221975_hashanthini;

public class Customer {
    private String first_name;
    private String second_name;
    private int no_burgers;

    public Customer(){

    }

    public Customer(String first_name, String second_name, int no_burgers){
        this.first_name = first_name;
        this.second_name = second_name;
        this.no_burgers = no_burgers;
    }

    public String getFirstName(){
        return this.first_name;
    }

    public String getSecondName(){
        return this.second_name;
    }

    public int getNo_burgers(){
        return this.no_burgers;
    }

    public void setFirst_name(String first_name){
        this.first_name = first_name;
    }

    public void setSecond_name(String second_name){
        this.second_name = second_name;
    }

    public void setNo_burgers(int no_burgers){
        this.no_burgers = no_burgers;
    }


}
