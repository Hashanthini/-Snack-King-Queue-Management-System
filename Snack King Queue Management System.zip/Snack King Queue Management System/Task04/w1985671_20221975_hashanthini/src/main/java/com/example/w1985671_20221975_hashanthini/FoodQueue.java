package com.example.w1985671_20221975_hashanthini;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class FoodQueue extends Application {
    static ArrayList<Customer> cashier1 = new ArrayList<>(2);
    static ArrayList<Customer> cashier2 = new ArrayList<>(3);
    static ArrayList<Customer> cashier3 = new ArrayList<>(5);
    static ArrayList<ArrayList<Customer>> allCashier = new ArrayList<>(); // 0, 1, 2
    static Customer[] queue = new Customer[100];
    static int[] listSize = {2, 3, 5};

    static double[] total_income = {0.0, 0.0, 0.0};

    static int burgers = 50;

    static int rear = Integer.MIN_VALUE;
    static int front = Integer.MIN_VALUE;
    static Scanner userInput = new Scanner(System.in);
    public TableView tableView1;
    public TableView tableView2;
    public TableView tableView3;
    public TableView tableView4;

    private TableView<Person> tableView;
    private ObservableList<String> firstNames;
    private ObservableList<String> lastNames;
    private ObservableList<Integer> ages;
    public static void main(String[] args) throws IOException {
        allCashier.add(cashier1);
        allCashier.add(cashier2);
        allCashier.add(cashier3);

        for (int i = 0; i < queue.length; i++){
            Customer customer = new Customer("Empty", "Empty", 0);
            queue[i] = customer;
        }
        //Display all the menu option
        System.out.println("100 or VFQ:View all Queues");
        System.out.println("101 or VEQ:View all Empty Queues");
        System.out.println("102 or ACQ:Add customer to a Queues");
        System.out.println("103 or RCQ:Remove a customer from a  Queue");
        System.out.println("104 or PCQ:Remove a served customer");
        System.out.println("105 or VCS:View  Customers Sorted in alphabetical order");
        System.out.println("106 or SPD:Store program Data into file");
        System.out.println("107 or LPD:Load Program Data from file");
        System.out.println("108 or AFS:Add burgers to  Stock");
        System.out.println("109 or VFS:View remaining burgers in Stock.");
        System.out.println("110 or IFQ:Income of each queue");
        System.out.println("112 or GUI:view the status of the queues");
        System.out.println("999 or EXT:Exit the  program.\n");
        String choice;
        do {

            System.out.print("Enter the menu number : ");
            choice = userInput.nextLine();


            switch (choice) {
                case "100", "VFQ" -> Queues();
                case "101", "VEQ" -> emptyQueue();
                case "102", "ACQ" -> addCustomer();
                case "103", "RCQ" -> removeCustomer();
                case "104", "PCQ" -> removeServedCustomer();
                case "105", "VCS" -> sortName();
                case "106", "SPD" -> savedInformationFile();
                case "107", "LPD" -> loadInformationFile();
                case "108", "STK" -> addBurgers();
                case "109", "AFS" -> viewBurgers();
                case "110", "IFQ" -> total_income_display();
                case "112", "GUI" -> launch(args);
                case "999", "EXT" -> System.out.println("Exiting program...");
            }
        } while (!choice.equals("999") && !choice.equals("EXT"));
    }

    public static void addCustomer(){
        System.out.println("Displaying the queue information below");
        Queues();

        int burgerCount = 0;
        System.out.print("Enter the customer first name : ");
        String firstName = userInput.nextLine();

        System.out.print("Enter the customer last name : ");
        String secondName = userInput.nextLine();

        while (true){
            System.out.print("Enter the customer burger count: ");
            burgerCount = userInput.nextInt();
            userInput.nextLine();

            if (burgerCount >= burgers)
                System.out.println("Sorry there are only " + burgers + " available at stock.\nEnter again");
            else
                break;
        }


        Customer person = new Customer(firstName, secondName, burgerCount);

        int maxSize = Integer.MAX_VALUE;
        int index =  -100;

        for (int i = 0; i < allCashier.size();i++){

            ArrayList<Customer> innerList = allCashier.get(i);

            int size = innerList.size();

            if (size >= listSize[i])
                continue;

            if (size < maxSize){
                maxSize = innerList.size();
                index = i;
            }
        }
        if (index == -100){
            System.out.println("Sorry the cashier is full");
            enqueue(person);
        }
        else
            allCashier.get(index).add(person);

        System.out.println();
    }

    public static void Queues(){
        System.out.println();

        int[] empty = new int [listSize.length];
        for (int i = 0; i < listSize.length; i++){
            empty[i] = listSize[i] - allCashier.get(i).size();
        }

        for (int i = 0; i < allCashier.size(); i++){
            System.out.print("Cashier " + (i + 1) + " : ");

            for (int j = 0; j < allCashier.get(i).size(); j++){

//                System.out.print(allCashier.get(i).get(j).getFirstName() +
//                        " " + allCashier.get(i).get(j).getSecondName() +
//                        " " + allCashier.get(i).get(j).getNo_burgers() + "  |  ");
                System.out.print("O | ");
            }

            for (int k = 0; k < empty[i]; k++)
                System.out.print("x | ");

            System.out.println();
        }

        for (int i = 0 ; i < cashier1.size(); i++)
            System.out.println(cashier1.get(i).getFirstName());
        System.out.println();
        System.out.println();

    }

    public static void emptyQueue(){
        int[] empty = new int [listSize.length];
        for (int i = 0; i < listSize.length; i++){
            empty[i] = listSize[i] - allCashier.get(i).size();
        }

        for (int i = 0; i < allCashier.size(); i++){
            System.out.print("Cashier " + (i + 1) + " : ");

            for (int k = 0; k < empty[i]; k++){
                System.out.print("x | ");
            }
            System.out.print(" : Total empty spaces  = " + empty[i] + "\n");
        }
    }

    public static void removeCustomer(){
        System.out.print("Enter the queue : ");
        int cashier = userInput.nextInt()-1;
        userInput.nextLine();

        System.out.print("Enter the customer's first name : ");
        String firstName = userInput.nextLine();
        System.out.println(firstName);

        for(int i = 0; i < allCashier.get(cashier).size(); i++){
            for(int j = 0; j < allCashier.get(i).size(); j++){
                if (allCashier.get(i).get(j).getFirstName().equals(firstName)){
                    allCashier.get(i).remove(j);
//                    dequeue(cashier);
                }
            }
        }
        System.out.println();
    }

    public static void removeServedCustomer(){
        System.out.print("Enter the queue : ");
        int cashier = userInput.nextInt()-1;
        userInput.nextLine();

        for(int i = 0; i < allCashier.get(cashier).size(); i++){
            double total = allCashier.get(i).get(0).getNo_burgers() * 650;
            total_income[i] += total;
            allCashier.get(i).remove(0);
        }
        dequeue(cashier);
        System.out.println();
    }

    public static void total_income_display(){
        for (int i = 0; i < total_income.length; i++)
            System.out.println("Cashier " + (i+1) + " : " + total_income[i]);
    }

    public static void sortName(){

        String[][] names = new String[allCashier.size()][];
        for (int i = 0; i < allCashier.size(); i++){
            names[i] = new String[allCashier.get(i).size()];
        }


        for (int i = 0; i < allCashier.size(); i++){
            for(int j = 0; j < allCashier.get(i).size(); j++){
                names[i][j]  = allCashier.get(i).get(j).getFirstName();
            }
        }

        for (int i = 0; i < names.length; i++){
            for(int j = 0; j < names[i].length-1; j++){
                if (names[i][j].compareTo(names[i][j+1]) > 0) {
                    String temp_firstName = names[i][j];
                    names[i][j] = names[i][j+1];
                    names[i][j+1] = temp_firstName;
                }
            }
        }

        int cashier_count = 1;

        for(String[] name_array : names){
            System.out.print("Cashier " + cashier_count + " : ");
            for (String name: name_array)
                System.out.print(name + " | ");
            cashier_count ++;
            System.out.println();
        }
    }
    public static void savedInformationFile() throws IOException{
        String holder = "";
        FileWriter fileWriter = new FileWriter("hashanthini.txt");

        for (int i = 0; i < allCashier.size(); i++){
            holder += "Cashier " + (i+1) + " : ";
            for (int j = 0; j < allCashier.get(i).size(); j++){
                holder += allCashier.get(i).get(j).getFirstName() + " " + allCashier.get(i).get(j).getSecondName() +
                        allCashier.get(i).get(j).getNo_burgers() + " | ";
            }
            holder += "\n";
        }

        fileWriter.write(holder);
        fileWriter.close();
    }

    public static void loadInformationFile() throws IOException{
        File file = new File("hashanthini.txt");
        Scanner scanner = new Scanner(file);

        while (scanner.hasNextLine())
            System.out.println(scanner.nextLine());
    }
    // add burgers to a stock
    public static void addBurgers(){
        Scanner inputUser = new Scanner(System.in);

        while (true){
            System.out.print("The current burger count : " + burgers +
                    "\nYou can add burgers till : " + (50 - burgers) + " (max storage limit)" +
                    "\n\nEnter the burgers to add in stock : ");
            int addCount = inputUser.nextInt();
            if (addCount<=0)
                System.out.println("Invalid value to add burgers to cashiers");

            else if ((addCount+burgers) >= 50){
                System.out.println("Sorry, it exceeds the count");
            }

            else {
                burgers = burgers+addCount;
                System.out.println("Burgers added to the count");
                break;
            }

        }

    }

    public static void viewBurgers(){
        System.out.println("Remaining burgers in stock : " + burgers);
    }

    public static void enqueue(Customer person){
        if (rear==Integer.MIN_VALUE && front==Integer.MIN_VALUE){
            front = rear = 0;
            queue[rear] = person;
            System.out.println("Customer added waiting queue");
        }

        else if ((rear+1) % queue.length == front) System.out.println("Waiting queue is full");

        else {
            rear = (rear+1)  % queue.length;
            queue[rear] = person;
            System.out.println("Customer added waiting queue");
        }
    }

    public static void dequeue(int cashier){
        if (rear == Integer.MIN_VALUE && front == Integer.MIN_VALUE)
            System.out.println();
        else if (rear==front){
            Customer customer = new Customer(queue[front].getFirstName(), queue[front].getSecondName(), queue[front].getNo_burgers());
            allCashier.get(cashier).add(customer);
            System.out.println("Customer from waiting queue added to cashier 1");
            initialize(front);
            rear = front = Integer.MIN_VALUE;
        }

        else {
            Customer customer = new Customer(queue[front].getFirstName(), queue[front].getSecondName(), queue[front].getNo_burgers());
            allCashier.get(cashier).add(customer);
            System.out.println("Customer from waiting queue added to cashier 2");
            initialize(front);
            front = (front + 1) % queue.length;
        }
    }

    public static void initialize(int index){
        queue[index].setFirst_name("empty");
        queue[index].setSecond_name("empty");
        queue[index].setNo_burgers(0);
    }


    @Override
    public void start(Stage primaryStage) throws IOException {
        // Load the hello-view.fxml file
        FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
        VBox root = loader.load();

        // Get references to the TableViews defined in the FXML by using the id of each table in FXML
        TableView<Person> tableView1 = (TableView<Person>) loader.getNamespace().get("tableView1");
        TableView<Person> tableView2 = (TableView<Person>) loader.getNamespace().get("tableView2");
        TableView<Person> tableView3 = (TableView<Person>) loader.getNamespace().get("tableView3");
        TableView<Person> tableView4 = (TableView<Person>) loader.getNamespace().get("tableView4");

        // Create an ArrayList of Cashier objects
        ArrayList<Person> people = new ArrayList<>();
        for (int i = 0; i < allCashier.get(0).size(); i++){
            people.add(new Person(allCashier.get(0).get(i).getFirstName(), allCashier.get(0).get(i).getSecondName(),
                                    allCashier.get(0).get(i).getNo_burgers()));
        }


        // Create an ObservableList from the ArrayList
        ObservableList<Person> cashier1_list = FXCollections.observableArrayList(people);

        // Set the items of the TableViews to the ObservableList
        tableView1.setItems(cashier1_list);


        // Create a new ObservableList for the second TableView
        ObservableList<Person> cashier2_list = FXCollections.observableArrayList();
        for (int i = 0; i < allCashier.get(1).size(); i++){
            cashier2_list.add(new Person(allCashier.get(1).get(i).getFirstName(), allCashier.get(1).get(i).getSecondName(),
                    allCashier.get(1).get(i).getNo_burgers()));
        }

        // Set the items of the second TableView
        tableView2.setItems(cashier2_list);


        // Create a new ObservableList for the second TableView
        ObservableList<Person> cashier3_list = FXCollections.observableArrayList();
        for (int i = 0; i < allCashier.get(2).size(); i++){
            cashier3_list.add(new Person(allCashier.get(2).get(i).getFirstName(), allCashier.get(2).get(i).getSecondName(),
                    allCashier.get(2).get(i).getNo_burgers()));
        }

        // Set the items of the second TableView
        tableView3.setItems(cashier3_list);

        // Create a new ObservableList for the second TableView
        ObservableList<Person> waiting_queue_list = FXCollections.observableArrayList();
        for (int i = 0; i < queue.length; i++){
            waiting_queue_list.add(new Person(queue[i].getFirstName(), queue[i].getSecondName(),
                    queue[i].getNo_burgers()));
        }

        // Set the items of the second TableView
        tableView4.setItems(waiting_queue_list);

        // Create the scene and set it on the stage
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("ArrayList Table Example");
        primaryStage.show();
    }

    public static class Person {
        private String firstName;
        private String lastName;

        private int burgerCount;
        public Person(String firstName, String lastName, int burgerCount) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.burgerCount = burgerCount;
        }

        public String getFirstName() {
            return firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public int getBurgerCount() {
            return burgerCount;
        }
    }
}