module com.example.w1985671_20221975_hashanthini {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.w1985671_20221975_hashanthini to javafx.fxml;
    exports com.example.w1985671_20221975_hashanthini;
}