public class Customer {

    // Given data at cw specification
    // Using private identifier to protect the data
    private String first_name;
    private String second_name;
    private int burger_count;

    // Creating local constructor
    public Customer(){

    }

    // Creating Parameterized constructor define each object

    public Customer(String first_name, String second_name, int burger_count){
        this.first_name = first_name;
        this.second_name = second_name;
        this.burger_count = burger_count;
    }

    // Defining encapsulation - Getters and setters
    public String getFirstName(){
        return this.first_name;
    }

    public String getSecondName(){
        return this.second_name;
    }

    public int getburger_count(){
        return this.burger_count;
    }

    public void setFirst_name(String first_name){
        this.first_name = first_name;
    }

    public void setSecond_name(String second_name){
        this.second_name = second_name;
    }

    public void setburger_count(int burger_count){
        this.burger_count = burger_count;
    }


}
