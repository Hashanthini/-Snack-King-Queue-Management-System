public class CircularQueue {
    static int[] queue = new int[10];
    static int rear = Integer.MIN_VALUE;
    static int front = Integer.MIN_VALUE;

    static int size = queue.length;

    public static void main(String[] args){
        enqueue(queue, 1);
        enqueue(queue, 2);
        enqueue(queue, 3);
        enqueue(queue, 4);
        enqueue(queue, 5);
        enqueue(queue, 6);
        enqueue(queue, 7);
        enqueue(queue, 8);
        enqueue(queue, 9);
        enqueue(queue, 10);
        dequeue(queue);
        dequeue(queue);
        dequeue(queue);
        dequeue(queue);
    }

    public static void enqueue(int[] queue, int value){
        if (rear==Integer.MIN_VALUE && front==Integer.MIN_VALUE){
            front = rear = 0;
            queue[rear] = value;
        }

        else if ((rear+1) % size == front) System.out.println("Queue is full");

        else{
            rear = (rear+1) % size;
            queue[rear] = value;
        }
        show();
    }

    public static void dequeue(int[] queue){
        if (rear == Integer.MIN_VALUE && front == Integer.MIN_VALUE)
            System.out.println("Queue is empty");

        else if (rear==front){
            queue[front] = 0;
            rear = front = Integer.MIN_VALUE;
        }

        else {
            queue[front] = 0;
            front = (front+1)%size;
        }
        show();

    }

    public static void show(){
        for (Object obj : queue)
            System.out.print(obj + " ");
        System.out.println();
    }
}
