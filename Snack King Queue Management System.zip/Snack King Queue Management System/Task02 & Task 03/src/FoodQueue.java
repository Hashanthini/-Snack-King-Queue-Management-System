import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class FoodQueue {

    // Defining each cashier arrayList

    // Cashier 1
    static ArrayList<Customer> cashier1_arrayList = new ArrayList<>(2);

    // Cashier 2
    static ArrayList<Customer> cashier2_arrayList = new ArrayList<>(3);

    // Cashier 3
    static ArrayList<Customer> cashier3_arrayList = new ArrayList<>(5);

    // Nested arrayList to hold all cashier
    static ArrayList<ArrayList<Customer>> nestedCashier_list = new ArrayList<>();

    // Defining array to store waiting queue customers
    static Customer[] customer_queue = new Customer[100];

    // Mentioning each cashier's size
    static int[] cashier_size = {2, 3, 5};

    // Array to store total income of each customer queue
    static double[] total_income = {0.0, 0.0, 0.0};

    // Static int to store burger count
    static int burger_count = 50;

    // Rear and Front for circular queue
    static int rear = Integer.MIN_VALUE;
    static int front = Integer.MIN_VALUE;
    static Scanner userInput = new Scanner(System.in);

    public static void main(String[] args) throws IOException {

        // Adding Each Cashier array into Nested Cashier Array
        nestedCashier_list.add(cashier1_arrayList);
        nestedCashier_list.add(cashier2_arrayList);
        nestedCashier_list.add(cashier3_arrayList);

        //Display all the menu option
        System.out.println("100 or VFQ:View all Queues()");
        System.out.println("101 or VEQ:View all Empty Queues()");
        System.out.println("102 or ACQ:Add customer to a Queues()");
        System.out.println("103 or RCQ:Remove a customer from a  Queue");
        System.out.println("104 or PCQ:Remove a served customer");
        System.out.println("105 or VCS:View  Customers Sorted in alphabetical order");
        System.out.println("106 or SPD:Store program Data into file");
        System.out.println("107 or LPD: Load Program Data from file");
        System.out.println("108 or AFS:Add burgers to  Stock");
        System.out.println("109 or VFS: View remaining burgers in Stock.");
        System.out.println("110 or IFQ: Income of each queue");
        System.out.println("999 or EXT:Exit the  program.\n");
        String choice;
        do {

            System.out.print("Enter the menu number : ");
            choice = userInput.nextLine();


            switch (choice) {
                case "100", "VFQ" -> Queues();
                case "101", "VEQ" -> emptyQueues();
                case "102", "ACQ" -> addCustomer();
                case "103", "RCQ" -> removeCustomer();
                case "104", "PCQ" -> removeServedCustomer();
                case "105", "VCS" -> sortName();
                case "106", "SPD" -> savedInformationfile();
                case "107", "LPD" -> loadInformationTextFile();
                case "108", "STK" -> addBurgers();
                case "109", "AFS" -> viewBurgers();
                case "110", "IFQ" -> total_income_display();
                case "999", "EXT" -> System.out.println("Exiting program...");
            }
        } while (!choice.equals("999") && !choice.equals("EXT"));
    }

    // Add customer method
    public static void addCustomer(){

        // Displaying customers
        System.out.println("Displaying the queue information below");
        Queues();

        // Getting customer inputs
        int burgerCount = 0;
        System.out.print("Enter the customer's first name : ");
        String firstName = userInput.nextLine();

        System.out.print("Enter the customer's last name : ");
        String lastName = userInput.nextLine();

        // Getting burger count of customer
        while (true){

            // If the burger count is greater than in stock count it will show to enter again
            // Or if the count is less than 0 it will warn
            System.out.print("Enter the customer's purchasing burger amount : ");
            burgerCount = userInput.nextInt();
            userInput.nextLine();

            if (burgerCount >= burger_count)
                System.out.println("In stock burger count : " + burger_count + " available at stock.\nEnter again please.");
            else if (burgerCount <= 0)
                System.out.println("Enter a valid count please.");
            else
                break;
        }

        // Creating the customer object
        Customer customer = new Customer(firstName, lastName, burgerCount);

        // Finding the minimum sized arrayList in nested array (cashiers)
        int max_count = Integer.MAX_VALUE;
        int index =  -100;

        for (int i = 0; i < nestedCashier_list.size(); i++){

            ArrayList<Customer> innerList = nestedCashier_list.get(i);

            int size = innerList.size();

            if (size >= cashier_size[i])
                continue;

            if (size < max_count){
                max_count = innerList.size();
                index = i;
            }
        }

        // If the index didn't change means there is no small arraylist, so the cashier is full
        if (index == -100){
            System.out.println("Sorry the cashier queue is full");
            enqueue(customer);
        }

        // If the arrayList is not full then adding customer object to arrayList
        else
            nestedCashier_list.get(index).add(customer);

        System.out.println();
    }

    // Displaying customers
    public static void Queues(){
        System.out.println();

        // Finding the empty spaces in each arrayList
        int[] empty = new int [cashier_size.length];
        for (int i = 0; i < cashier_size.length; i++){
            empty[i] = cashier_size[i] - nestedCashier_list.get(i).size();
        }

        // Displaying cashier queue information
        for (int i = 0; i < nestedCashier_list.size(); i++){
            System.out.print("Cashier " + (i + 1) + " : ");

            for (int j = 0; j < nestedCashier_list.get(i).size(); j++){

                // Uncomment to display the names
//                System.out.print(allCashier.get(i).get(j).getFirstName() +
//                        " " + allCashier.get(i).get(j).getSecondName() +
//                        " " + allCashier.get(i).get(j).getburger_count() + "  |  ");
                System.out.print("O | ");
            }

            // Displaying the empty in cashier
            for (int k = 0; k < empty[i]; k++)
                System.out.print("x | ");

            System.out.println();
        }
        System.out.println();
        System.out.println();

    }


    // Method to display empty slots in queue
    public static void emptyQueues(){

        // Display empty slot in queue
        int[] empty = new int [cashier_size.length];

        // Getting empty slot sizes
        for (int i = 0; i < cashier_size.length; i++){
            empty[i] = cashier_size[i] - nestedCashier_list.get(i).size();
        }

        // Displaying empty slots in queue
        for (int i = 0; i < nestedCashier_list.size(); i++){
            System.out.print("Cashier " + (i + 1) + " : ");

            for (int k = 0; k < empty[i]; k++){
                System.out.print("x | ");
            }

            // Displaying total empty spaces
            System.out.print(" : Total empty spaces  = " + empty[i] + "\n");
        }
    }


    // Method to remove specific customer
    public static void removeCustomer(){

        // Getting the queue number from user
        System.out.print("Enter the cashier queue number: ");
        int cashier_number = userInput.nextInt()-1;
        userInput.nextLine();

        // Getting customer's first name
        System.out.print("Enter the removing customer's first name : ");
        String firstName = userInput.nextLine();

        // Removing the customer from queue
        for(int i = 0; i < nestedCashier_list.get(cashier_number).size(); i++){
            for(int j = 0; j < nestedCashier_list.get(i).size(); j++){
                if (nestedCashier_list.get(i).get(j).getFirstName().equals(firstName)){
                    nestedCashier_list.get(i).remove(j);

                    // Uncomment the below line to check dequeue function - it disabled, since cw mentioned only for served
                    // dequeue(cashier);
                }
            }
        }
        System.out.println();
    }

    // Removing the served customer
    public static void removeServedCustomer(){

        // Getting the cashier queue
        System.out.print("Enter the cashier queue number: ");
        int cashier_number = userInput.nextInt()-1;
        userInput.nextLine();

        for(int i = 0; i < nestedCashier_list.get(cashier_number).size(); i++){
            double burger_cost = nestedCashier_list.get(i).get(0).getburger_count() * 650;
            total_income[i] += burger_cost;
            nestedCashier_list.get(i).remove(0);
        }
        dequeue(cashier_number);
        System.out.println();
    }

    // Displaying total income of each queue
    public static void total_income_display(){
        // Total income of each queue
        for (int i = 0; i < total_income.length; i++)
            System.out.println("Cashier " + (i+1) + " - " + total_income[i]);
    }

    // Method to sort the customers
    public static void sortName(){
        // Variable to store cashier number
        int cashier_number = 1;

        // Creating a dummy nested jagged to duplicate data
        String[][] first_names = new String[nestedCashier_list.size()][];

        // Initializing the array lengths.
        for (int i = 0; i < nestedCashier_list.size(); i++){
            first_names[i] = new String[nestedCashier_list.get(i).size()];
        }

        // Duplicating the first names
        for (int i = 0; i < nestedCashier_list.size(); i++){
            for(int j = 0; j < nestedCashier_list.get(i).size(); j++){
                first_names[i][j]  = nestedCashier_list.get(i).get(j).getFirstName();
            }
        }


        // Sorting the names based on bubble sort theory
        for (int i = 0; i < first_names.length; i++){
            for(int j = 0; j < first_names[i].length-1; j++){
                if (first_names[i][j].compareTo(first_names[i][j+1]) > 0) {
                    String temp_firstName = first_names[i][j];
                    first_names[i][j] = first_names[i][j+1];
                    first_names[i][j+1] = temp_firstName;
                }
            }
        }

        // Displaying the first name
        for(String[] first_name : first_names){
            System.out.print("Cashier " + cashier_number + " : ");
            for (String name: first_name)
                System.out.print(name + " | ");
            cashier_number ++;
            System.out.println();
        }
    }

    // Saving data into text files
    public static void savedInformationfile() throws IOException{

        // Creating the string container variable
        String holder = "";

        // Creating the fileWritter class to write on file
        FileWriter fileWriter = new FileWriter("w1985671_hashanthini.txt");

        // Concatenating the string variable
        for (int i = 0; i < nestedCashier_list.size(); i++){
            holder += "Cashier " + (i+1) + " : ";
            for (int j = 0; j < nestedCashier_list.get(i).size(); j++){
                holder += nestedCashier_list.get(i).get(j).getFirstName() + " " + nestedCashier_list.get(i).get(j).getSecondName() +
                        nestedCashier_list.get(i).get(j).getburger_count() + " | ";
            }
            holder += "\n";
        }

        // Writing on the text file
        fileWriter.write(holder);

        // Closing the text file
        fileWriter.close();
    }

    // Method load the text file and read it
    public static void loadInformationTextFile() throws IOException{

        // File class to read the file
        File file = new File("w1985671_hashanthini.txt");
        Scanner scanner = new Scanner(file);

        // Printing the file data, line by line
        while (scanner.hasNextLine())
            System.out.println(scanner.nextLine());
    }


    // method to add burgers to stock
    public static void addBurgers(){
        Scanner inputUser = new Scanner(System.in);

        // Conditions
        while (true){
            System.out.print("The current burger count : " + burger_count +
                    "\nYou can add burgers till : " + (50 - burger_count) + " (max storage limit)" +
                    "\n\nEnter the burgers to add in stock : ");
            int addCount = inputUser.nextInt();

            // If the burger adding count is less than 0, request user to enter again
            if (addCount<0)
                System.out.println("Invalid value to add burgers to cashiers");

            // If the burger adding count + stock burger count is greater than 50, request user to enter again
            else if ((addCount+ burger_count) > 50){
                System.out.println("Sorry, it exceeds the count");
            }

            // Else adding the burger to stock
            else {
                burger_count = burger_count +addCount;
                System.out.println("Burgers added to the count");
                break;
            }

        }

    }

    // Displaying the burgers in stock
    public static void viewBurgers(){
        System.out.println("Remaining burgers in stock : " + burger_count);
    }

    // Enqueue operator of circular queue
    public static void enqueue(Customer customer){

        // If rear and front are still min value of int then initializing them to 0 and adding customer data
        if (rear==Integer.MIN_VALUE && front==Integer.MIN_VALUE){
            front = rear = 0;
            customer_queue[rear] = customer;
            System.out.println("Customer added to the waiting queue. Continue");
        }

        // If this condition gets true then warning user that waiting queue is full
        else if ((rear+1) % customer_queue.length == front) System.out.println("Waiting customer queue is full");

        // If above conditions are false then adding customer to the queue and changing rear value
        else {
            rear = (rear+1)  % customer_queue.length;
            customer_queue[rear] = customer;
            System.out.println("Customer added waiting queue");
        }
    }

    // Dequeue operator of circular queue
    public static void dequeue(int cashier){

        // if both rear and front are same, means queue doesnt have any value so leaving like that
        if (rear == Integer.MIN_VALUE && front == Integer.MIN_VALUE)
            System.out.println();

        // If both are same then assigning waiting queue customer to cashier and change the rear and front value min int again
        else if (rear==front){
            Customer customer = new Customer(customer_queue[front].getFirstName(), customer_queue[front].getSecondName(), customer_queue[front].getburger_count());
            nestedCashier_list.get(cashier).add(customer);
            System.out.println("Customer from waiting queue added to cashier 1");
            initialize(front);
            rear = front = Integer.MIN_VALUE;
        }

        // If both above are false then adding waited customer to queue and changing only front value
        else {
            Customer customer = new Customer(customer_queue[front].getFirstName(), customer_queue[front].getSecondName(), customer_queue[front].getburger_count());
            nestedCashier_list.get(cashier).add(customer);
            System.out.println("Customer from waiting queue added to cashier 2");
            initialize(front);
            front = (front + 1) % customer_queue.length;
        }
    }

    public static void initialize(int index){
        customer_queue[index].setFirst_name("empty");
        customer_queue[index].setSecond_name("empty");
        customer_queue[index].setburger_count(0);
    }
}
