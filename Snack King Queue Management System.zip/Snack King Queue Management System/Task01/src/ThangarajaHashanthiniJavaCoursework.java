import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalTime;

public class ThangarajaHashanthiniJavaCoursework{
    static String[] cashier1 = {"X","X"};
    static String[] cashier2 = {"X","X","X"};
    static String[] cashier3 = {"X","X","X","X","X"};
    static int burger_count = 50;

    public static void main (String[] args)throws IOException{
        Queues();
        showMenu();
    }

    public static void showMenu() throws IOException{
        while(true){
            System.out.println();

            if(burger_count == 10){
                System.out.println("Remaining burger count is " + burger_count);
            }

            System.out.println("--------------------------------");

            LocalDate currentDate = LocalDate.now();                // Get the current date
            System.out.println("Current Date: " + currentDate);     // print the current date

            LocalTime currentTime = LocalTime.now();                 // Get the current time
            System.out.println("Current Time: " + currentTime);      // print the current time

            System.out.println("--------------------------------");
            System.out.println("Foodies Fave Food center - Menu");
            System.out.println("--------------------------------");
            System.out.println("100 or VFQ: View all Queues.");
            System.out.println("101 or VEQ: View all Empty Queues.");
            System.out.println("102 or ACQ: Add customer to a Queue.");
            System.out.println("103 or RCQ: Remove a customer from a Queue. (From a specific location)");
            System.out.println("104 or PCQ: Remove a served customer.");
            System.out.println("105 or VCS: View Customers Sorted in alphabetical order (Do not use library sort routine)");
            System.out.println("106 or SPD: Store Program Data into file.");
            System.out.println("107 or LPD: Load Program Data from file.");
            System.out.println("108 or STK: View Remaining burgers Stock.");
            System.out.println("109 or AFS: Add burgers to Stock.");
            System.out.println("999 or EXT: Exit the Program.");
            System.out.println("--------------------------------");
            System.out.println(" ");

            Scanner input = new Scanner(System.in);
            System.out.println("Please choose an option form the menu:");
            String option = input.nextLine().toUpperCase();
            System.out.println(" ");

            if(option.equals("100") || (option.equals("VFQ"))) {
                Queues();
            }

            else if(option.equals("101") || (option.equals("VEQ"))) {
                emptyQueues();
            }

            else if(option.equals("102") || (option.equals("ACQ"))) {
                addCustomer();
                Queues();
            }

            else if(option.equals("103") || (option.equals("RCQ"))) {
                removeCustomer();
                Queues();
            }

            else if(option.equals("104") || (option.equals("PCQ"))) {
                removeServedCustomer();
                Queues();
                burger_count = burger_count -5;
                System.out.println(" ");

            }

            else if(option.equals("105") || (option.equals("VCS"))) {
                sortName();
            }

            else if(option.equals("106") || (option.equals("SPD"))) {
                savedInformationfile();
            }

            else if(option.equals("107") || (option.equals("LPD"))) {
                loadInformationTextFile();
            }

            else if(option.equals("108") || (option.equals("STK"))) {
                System.out.println("Burger count is "+ burger_count);
            }

            else if(option.equals("109") || (option.equals("AFS"))) {
                System.out.println("Burger count is "+ burger_count);
                Scanner input4 = new Scanner(System.in);
                System.out.println("Enter the number of burger you want to add:");
                int new_burger = input4.nextInt();
                burger_count = burger_count + new_burger;
                System.out.println("Burger count is "+ burger_count);
                System.out.println(" ");

            }

            else if(option.equals("999") || (option.equals("EXT"))) {
                break;
            }

            else {
                System.out.println("Please select a valid option");
            }
        }
    }

    public static void  Queues(){

        System.out.println("*****************");
        System.out.println("*"+"    Cashiers   "+"*");
        System.out.println("*****************");
        System.out.println("c1      c2      c3");

        for (int i = 0; i < cashier3.length; i++) {
            try{
                if (cashier1[i].equals("X"))
                    System.out.print("X       ");
                else
                    System.out.print("O       ");
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (cashier2[i].equals("X"))
                    System.out.print("X       ");
                else
                    System.out.print("O       ");
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (cashier3[i].equals("X"))
                    System.out.print("X       ");
                else
                    System.out.print("O       ");
            }
            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("       ");
            }
            System.out.println();
        }
        System.out.println("O: Occupied  X: Not Occupied ");
    }

    public static void emptyQueues(){

        System.out.println("*****************");
        System.out.println("*"+"    Cashiers   "+"*");
        System.out.println("*****************");
        System.out.println("c1      c2      c3");

        for (int i = 0; i < cashier3.length; i++) {
            try{
                if (cashier1[i] == "X"){
                    System.out.print(cashier1[i] + "       ");
                }
                else{
                    System.out.print("        ");
                }
            }

            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (cashier2[i] == "X"){
                    System.out.print(cashier2[i] + "       ");
                }
                else{
                    System.out.print("        ");
                }
            }

            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

            try{
                if (cashier3[i] == "X"){
                    System.out.println(cashier3[i] + "       ");
                }
                else{
                    System.out.println("        ");
                }
            }

            catch(ArrayIndexOutOfBoundsException e){
                System.out.print("        ");
            }

        }
        System.out.println("O: Occupied  X: Not Occupied ");
    }

    public static void addCustomer(){

        Scanner input3 = new Scanner(System.in);
        System.out.println("Enter the customer name:");
        String name = input3.nextLine();
        System.out.println(" ");


        if (cashier1[0] == "X"){
            cashier1[0] = name;
        }

        else if (cashier2[0] == "X"){
            cashier2[0] = name;
        }

        else if (cashier3[0] == "X"){
            cashier3[0] = name;
        }

        else if (cashier1[1] == "X"){
            cashier1[1] = name;
        }

        else if (cashier2[1] == "X"){
            cashier2[1] = name;
        }

        else if (cashier3[1] == "X"){
            cashier3[1] = name;
        }

        else if (cashier2[2] == "X"){
            cashier2[2] = name;
        }

        else if (cashier3[2] == "X"){
            cashier3[2] = name;
        }

        else if (cashier3[3] == "X"){
            cashier3[3] = name;
        }

        else if (cashier3[4] == "X"){
            cashier3[4] = name;
        }

        else{
            System.out.println("All the cashier is full.Please wait for a while!");
        }
    }

    public static void removeCustomer(){
        Scanner input1 = new Scanner(System.in);
        System.out.println("Choose the cashier you want to remove the customer from(c1 or c2 or c3):");
        String removeCustomer = input1.nextLine();
        System.out.println(" ");

        if (removeCustomer.equals("c3")){
            System.out.println("Choose the position you want to remove the customer from 1 or 2 or 3 or 4 or 5: ");
            int position = input1.nextInt();
            cashier3[position -1] = "X";
        }

        else if (removeCustomer.equals("c2")){
            System.out.println("Choose the position you want to remove the customer from 1 or 2 or 3: ");
            int position = input1.nextInt();
            cashier2[position -1] = "X";
        }

        else if (removeCustomer.equals("c1")){
            System.out.println("Choose the position you want to remove the customer from 1 or 2 : ");
            int position = input1.nextInt();
            cashier2[position -1] = "X";
        }

        else{
            System.out.println("Invalid selection.");
        }
    }


    public static void removeServedCustomer(){
        Scanner input1 = new Scanner(System.in);
        System.out.println("Choose the cashier you want to remove the customer from(c1 or c2 or c3):");
        String removeCustomer = input1.nextLine();
        System.out.println(" ");

        if (removeCustomer.equals("c3")){

            if (!cashier3[4].equals("X")){
                cashier3[4] = "X";
            }

            else if (!cashier3[3].equals("X")){
                cashier3[3] = "X";
            }

            else if (!cashier3[2].equals("X")){
                cashier3[2] = "X";
            }

            else if (!cashier3[1].equals("X")){
                cashier3[1] = "X";
            }

            else if (!cashier3[0].equals("X")){
                cashier3[0] = "X";
            }

            else{
                System.out.println("Sorry this cashiers is already empty.");
            }
        }

        else if (removeCustomer.equals("c2")){

            if (!cashier2[2].equals("X")){
                cashier2[2] = "X";
            }

            else if (!cashier2[1].equals("X")){
                cashier2[1] = "X";
            }

            else if (!cashier2[0].equals("X")){
                cashier2[0] = "X";
            }

            else{
                System.out.println("Sorry this cashiers is already empty.");
            }
        }

        else if (removeCustomer.equals("c1")){

            if (!cashier1[1].equals("X")){
                cashier1[1] = "X";
            }

            else if (!cashier1[0].equals("X")){
                cashier1[0] = "X";
            }

            else{
                System.out.println("Sorry this cashiers is  already empty.");
            }
        }

        else{
            System.out.println("Invalid selection.");
        }
    }

    public static void sortName(){
        String[] temp_cashier1 = new String[2];
        String[] temp_cashier2 = new String[3];
        String[] temp_cashier3 = new String[5];

        for(int i = 0; i < cashier1.length; i++) temp_cashier1[i] = cashier1[i];
        for(int i = 0; i < cashier2.length; i++) temp_cashier2[i] = cashier2[i];
        for(int i = 0; i < cashier3.length; i++) temp_cashier3[i] = cashier3[i];

        for(int external = 0; external < temp_cashier1.length; external++){
            for(int internal = 0; internal < temp_cashier1.length - 1; internal++){
                if (temp_cashier1[internal].compareTo(temp_cashier1[internal + 1]) > 0 ){
                    String tempName = temp_cashier1[internal];
                    temp_cashier1[internal] = temp_cashier1[internal+1];
                    temp_cashier1[internal+1] = tempName;
                }
            }
        }

        for(int external = 0; external < temp_cashier2.length; external++){
            for(int internal = 0; internal < temp_cashier2.length - 1; internal++){
                if (temp_cashier2[internal].compareTo(temp_cashier2[internal + 1]) > 0 ){
                    String tempName = temp_cashier2[internal];
                    temp_cashier2[internal] = temp_cashier2[internal+1];
                    temp_cashier2[internal+1] = tempName;
                }
            }
        }

        for(int external = 0; external < temp_cashier3.length; external++){
            for(int internal = 0; internal < temp_cashier3.length - 1; internal++){
                if (temp_cashier3[internal].compareTo(temp_cashier3[internal + 1]) > 0 ){
                    String tempName = temp_cashier3[internal];
                    temp_cashier3[internal] = temp_cashier3[internal+1];
                    temp_cashier3[internal+1] = tempName;
                }
            }
        }

        System.out.print("Cashier 1 - Sorted names : ");
        for (String name: temp_cashier1)
        {
            if (!name.equals("X"))
                System.out.print(name + " ");

        }

        System.out.print("\nCashier 2 - Sorted names : ");
        for (String name: temp_cashier2)
        {
            if (!name.equals("X"))
                System.out.print(name + " ");

        }

        System.out.print("\nCashier 3 - Sorted names : ");
        for (String name: temp_cashier3)
        {
            if (!name.equals("X"))
                System.out.print(name + " ");

        }
        System.out.println();
    }

    public static void savedInformationfile() throws IOException{
        String holder = "";
        holder = "Cashier 1 : ";
        for(int i = 0; i < cashier1.length; i++){
            if (cashier1[i].equals("X"))
                holder += "X ";
            else
                holder += cashier1[i] + " ";
        }
        holder += "\nCashier 2 : ";
        for(int i = 0; i < cashier2.length; i++){
            if (cashier2[i].equals("X"))
                holder += "X ";
            else
                holder += cashier2[i] + " ";
        }

        holder += "\nCashier 3 : ";
        for(int i = 0; i < cashier2.length; i++){
            if (cashier2[i].equals("X"))
                holder += "X ";
            else
                holder += cashier2[i] + " ";
        }

        FileWriter writeObj =  new FileWriter("hasha.txt");
        writeObj.write(holder);
        writeObj.close();
    }

    public static void loadInformationTextFile() throws IOException{
        File readObj = new File("hasha.txt");

        Scanner scannerFile = new Scanner(readObj);

        while (scannerFile.hasNextLine())
            System.out.println(scannerFile.nextLine());
    }
}
